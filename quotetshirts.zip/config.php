<?php
     $ssactivewear_config = array(
        'Account number'   => '72348', // Merchant/SellerID
        'access_key'    => '023f94c9-dd3f-4543-bfb5-ed82f0b2cbcc', // MWS Access Key
    ); 
}

?>